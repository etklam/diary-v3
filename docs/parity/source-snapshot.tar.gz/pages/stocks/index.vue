<template>
  <PageContainer width="wide" class="stocks-page min-h-screen pb-20">
    <!-- Header -->
    <header class="py-6">
      <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div class="min-w-0">
          <h1 class="flex items-center gap-3 font-display text-2xl font-semibold tracking-tight text-dt-text sm:text-3xl">
            <Icon name="heroicons:presentation-chart-line" class="text-dt-primary" />
            {{ t('stock.dashboard.title') }}
          </h1>
          <div class="mt-1 flex flex-wrap items-center gap-3">
            <p class="text-sm text-dt-text-muted">
              {{ t('stock.dashboard.manageDescription') }}
            </p>
            <span v-if="marketState" class="inline-flex items-center gap-1.5 rounded-full border border-dt-border bg-dt-surface-strong px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-dt-text-muted">
              <span class="h-1.5 w-1.5 rounded-full" :class="marketState === 'REGULAR' ? 'bg-dt-success animate-pulse' : 'bg-dt-warning'"></span>
              {{ t('stock.dashboard.marketState') }}: {{ marketStateLabel }}
            </span>
          </div>
        </div>
        <div class="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:items-center sm:gap-3">
          <NuxtLink to="/stocks/watchlist" class="action-btn-muted-dashboard w-full sm:w-auto">
            <Icon name="heroicons:queue-list" class="w-4 h-4 mr-2" />
            {{ t('stock.watchlist.title') }}
          </NuxtLink>
          <button
            @click="fetchStockPrices"
            :disabled="isFetchingPrices || cooldownRemaining > 0 || pending"
            class="action-btn-dashboard group w-full sm:w-auto"
          >
            <Icon :name="(isFetchingPrices || pending) ? 'svg-spinners:180-ring-with-bg' : 'heroicons:arrow-path'" class="w-4 h-4 mr-2 group-hover:rotate-180 transition-transform duration-500" />
            {{ (isFetchingPrices || pending) ? t('stock.fetching') : cooldownRemaining > 0 ? `${cooldownRemaining}s` : t('stock.dashboard.refresh') }}
          </button>
          <NuxtLink to="/" class="action-btn-muted-dashboard w-full sm:w-auto">
            <Icon name="heroicons:home" class="w-4 h-4 mr-2" />
            {{ t('stock.dashboard.home') }}
          </NuxtLink>
        </div>
      </div>
    </header>

    <!-- Main Content Grid -->
    <section>
      <!-- Top Stats Grid -->
      <ErrorState
        v-if="loadError"
        :title="t('stock.dashboard.loadFailed')"
        :message="loadError.message"
        :retry-fn="refreshHoldings"
      />

      <section
        v-else-if="!pending && totalHoldings === 0"
        class="panel-dashboard mb-6 p-8 text-center"
        aria-labelledby="portfolio-empty-title"
      >
        <Icon name="heroicons:chart-bar-square" class="mx-auto h-10 w-10 text-dt-text-soft" />
        <h2 id="portfolio-empty-title" class="font-display mt-3 text-2xl text-dt-text">
          {{ t('stock.dataQuality.emptyTitle') }}
        </h2>
        <p class="mx-auto mt-2 max-w-lg text-sm text-dt-text-muted">
          {{ t('stock.dataQuality.emptyDescription') }}
        </p>
        <div class="mt-5 flex flex-wrap justify-center gap-3">
          <NuxtLink to="/diaries/new" class="action-btn-dashboard">{{ t('stock.dataQuality.addTransaction') }}</NuxtLink>
          <NuxtLink to="/stocks/watchlist" class="action-btn-muted-dashboard">{{ t('stock.dataQuality.openWatchlist') }}</NuxtLink>
        </div>
      </section>

      <div v-else-if="pending" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div v-for="i in 4" :key="i" class="stats-card animate-pulse">
          <div class="h-3 bg-dt-surface-strong rounded w-20 mb-3"></div>
          <div class="h-7 bg-dt-surface-strong rounded w-28"></div>
        </div>
      </div>

      <div v-else-if="totalHoldings > 0" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <!-- Portfolio Value -->
        <div class="stats-card">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-semibold uppercase tracking-wider text-dt-text-muted">{{ t('stock.dashboard.netLiquidity') }}</span>
            <Icon name="heroicons:banknotes" class="h-5 w-5 text-dt-primary opacity-50" />
          </div>
          <div class="font-data text-2xl font-bold tabular-nums text-dt-text">
            {{ currentMarketValue !== null ? formatCurrency(currentMarketValue) : t('stock.dataQuality.unavailable') }}
          </div>
          <div v-if="unrealizedAmount !== null" class="flex items-center gap-1.5 mt-1">
            <span class="text-xs font-medium" :class="(unrealizedAmount || 0) >= 0 ? 'text-dt-success' : 'text-dt-danger'">
              {{ (unrealizedAmount || 0) >= 0 ? '+' : '' }}{{ formatCurrency(unrealizedAmount || 0) }}
            </span>
            <span class="text-[10px] text-dt-text-soft">{{ t('stock.dashboard.totalPL') }}</span>
          </div>
        </div>

        <!-- Day Change -->
        <div class="stats-card">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-semibold uppercase tracking-wider text-dt-text-muted">{{ t('stock.dashboard.dayChange') }}</span>
            <Icon name="heroicons:bolt" class="h-5 w-5 text-dt-warning opacity-50" />
          </div>
          <div class="text-2xl font-bold tabular-nums" :class="(totalDayChange ?? 0) >= 0 ? 'text-dt-success' : 'text-dt-danger'">
            {{ totalDayChange === null ? t('stock.dataQuality.unavailable') : `${totalDayChange >= 0 ? '+' : ''}${formatCurrency(totalDayChange)}` }}
          </div>
          <div v-if="totalDayChangePercent !== null" class="flex items-center gap-1.5 mt-1">
            <span class="text-xs font-medium" :class="(totalDayChange ?? 0) >= 0 ? 'text-dt-success' : 'text-dt-danger'">
              {{ (totalDayChange ?? 0) >= 0 ? '+' : '' }}{{ totalDayChangePercent.toFixed(2) }}%
            </span>
            <span class="text-[10px] text-dt-text-soft">{{ t('stock.dashboard.today') }}</span>
          </div>
        </div>

        <!-- Margin/Equity Ratio or Total Cost -->
        <div class="stats-card">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-semibold uppercase tracking-wider text-dt-text-muted">{{ t('stock.dashboard.totalInvested') }}</span>
            <Icon name="heroicons:credit-card" class="h-5 w-5 text-dt-info opacity-50" />
          </div>
          <div class="font-data text-2xl font-bold tabular-nums text-dt-text">
            {{ formatCurrency(totalCost) }}
          </div>
          <div class="flex items-center gap-1.5 mt-1">
            <span class="text-xs font-medium text-dt-text-muted">
              {{ totalHoldings }} {{ t('stock.dashboard.positions') }}
            </span>
            <span class="text-[10px] text-dt-text-soft">{{ t('stock.dashboard.active') }}</span>
          </div>
        </div>

        <!-- Unrealized P/L % -->
        <div class="stats-card">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-semibold uppercase tracking-wider text-dt-text-muted">{{ t('stock.dashboard.unrealizedPLPercent') }}</span>
            <Icon name="heroicons:arrow-trending-up" class="h-5 w-5 text-dt-success opacity-50" />
          </div>
          <div class="text-2xl font-bold tabular-nums" :class="(totalUnrealizedPct ?? 0) >= 0 ? 'text-dt-success' : 'text-dt-danger'">
            {{ totalUnrealizedPct === null ? t('stock.dataQuality.unavailable') : `${totalUnrealizedPct >= 0 ? '+' : ''}${totalUnrealizedPct.toFixed(2)}%` }}
          </div>
          <div v-if="totalUnrealizedPct !== null" class="flex items-center gap-1.5 mt-1">
            <div class="w-full bg-dt-surface-strong h-1 rounded-full overflow-hidden">
              <div 
                class="h-full" 
                :class="totalUnrealizedPct >= 0 ? 'bg-dt-success' : 'bg-dt-danger'"
                :style="{ width: Math.min(Math.abs(totalUnrealizedPct) * 2, 100) + '%' }"
              ></div>
            </div>
          </div>
        </div>
      </div>

      <section
        v-if="totalHoldings > 0"
        class="panel-dashboard mb-6 p-4"
        :aria-label="t('stock.dataQuality.title')"
        role="status"
      >
        <div class="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 class="text-sm font-bold text-dt-text">{{ t('stock.dataQuality.title') }}</h2>
            <p class="mt-1 text-xs text-dt-text-muted">
              {{ t(`stock.dataQuality.status.${valuationStatus}`, { priced: pricedPositionCount, total: totalHoldings, cost: formatCurrency(unpricedCostBasis) }) }}
            </p>
          </div>
          <div class="text-right text-xs text-dt-text-muted">
            <p>{{ t('stock.dataQuality.coverage', { percent: quoteCoveragePct.toFixed(0) }) }}</p>
            <p v-if="valuationAsOf">{{ t('stock.dataQuality.asOf', { time: formatQuoteTime(valuationAsOf) }) }}</p>
            <p v-if="staleQuoteCount > 0" class="text-dt-warning">{{ t('stock.dataQuality.stale', { count: staleQuoteCount }) }}</p>
          </div>
        </div>
        <p class="mt-3 border-t border-dt-border pt-3 text-xs text-dt-text-soft">
          {{ t('stock.dataQuality.unsupported') }}
        </p>
      </section>

      <section class="panel-dashboard p-6 mb-6">
        <div class="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 class="font-bold text-dt-text flex items-center gap-2 text-base">
              <Icon name="heroicons:shield-exclamation" class="text-dt-warning" />
              {{ t('stock.riskSummary.title') }}
            </h2>
            <p class="mt-1 text-xs text-dt-text-muted">
              {{ t('stock.riskSummary.description') }}
            </p>
          </div>
          <span
            class="rounded-full px-3 py-1 text-xs font-bold"
            :class="concentrationWarning ? 'bg-dt-warning/10 text-dt-warning' : 'bg-dt-success/10 text-dt-success'"
          >
            {{ concentrationWarning ? t('stock.riskSummary.warning') : t('stock.riskSummary.balanced') }}
          </span>
        </div>

        <div class="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <div class="risk-metric">
            <span>{{ t('stock.riskSummary.largestPosition') }}</span>
            <strong>{{ largestPositionPct === null ? '—' : `${largestPositionPct.toFixed(1)}%` }}</strong>
            <small>{{ largestPositionSymbol || t('stock.riskSummary.noPosition') }}</small>
          </div>
          <div class="risk-metric">
            <span>{{ t('stock.riskSummary.top3Concentration') }}</span>
            <strong>{{ top3ConcentrationPct === null ? '—' : `${top3ConcentrationPct.toFixed(1)}%` }}</strong>
            <small>{{ unpricedPositionCount > 0 ? t('stock.dataQuality.pricedSubset') : t('stock.riskSummary.byValue') }}</small>
          </div>
          <div class="risk-metric">
            <span>{{ t('stock.riskSummary.activePositionCount') }}</span>
            <strong>{{ activePositionCount }}</strong>
            <small>{{ t('stock.dashboard.positions') }}</small>
          </div>
          <div class="risk-metric">
            <span>{{ t('stock.riskSummary.unrealizedPnl') }}</span>
            <strong :class="(unrealizedAmount ?? 0) >= 0 ? 'text-dt-success' : 'text-dt-danger'">
              {{ unrealizedAmount === null ? '—' : `${unrealizedAmount >= 0 ? '+' : ''}${formatCurrency(unrealizedAmount)}` }}
            </strong>
            <small>{{ totalUnrealizedPct === null ? t('stock.dataQuality.unavailable') : `${totalUnrealizedPct >= 0 ? '+' : ''}${totalUnrealizedPct.toFixed(2)}%` }}</small>
          </div>
          <div class="risk-metric">
            <span>{{ t('stock.riskSummary.priceBasis') }}</span>
            <strong>{{ t(`stock.dataQuality.statusLabel.${valuationStatus}`) }}</strong>
            <small>{{ t('stock.dataQuality.noCostFallback') }}</small>
          </div>
        </div>
      </section>

      <!-- ── Portfolio Exposure vs Suggested Allocation (T7) ── -->
      <section class="mb-6">
        <PortfolioExposurePanel
          :exposure="portfolioExposure"
          :gaps="portfolioExposureGaps"
          :beta-allocation="portfolioBetaAllocation"
          :market-state="portfolioExposureMarketState"
          :last-updated="portfolioExposureLastUpdated"
          :pending="portfolioExposurePending"
        />
      </section>

      <!-- Main Layout Grid: Holdings Table (Left) + Portfolio Analysis (Right) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Holdings Table Section -->
        <div class="lg:col-span-8 space-y-6">
          <div class="panel-dashboard overflow-hidden">
            <div class="px-6 py-4 border-b border-dt-border flex items-center justify-between bg-dt-surface-strong">
              <h3 class="font-bold text-dt-text flex items-center gap-2 text-base">
                <Icon name="heroicons:list-bullet" class="text-dt-info" />
                {{ t('stock.dashboard.activePositions') }}
              </h3>
              <div class="flex items-center gap-2">
                <div class="relative">
                  <Icon name="heroicons:magnifying-glass" class="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-dt-text-soft" />
                  <input
                    v-model="searchQuery"
                    type="text"
                    :placeholder="t('stock.dashboard.searchPlaceholder')"
                    class="pl-8 pr-3 py-1.5 text-xs rounded-dt-sm border border-dt-border bg-dt-surface-strong text-dt-text placeholder:text-dt-text-soft focus:outline-none focus:ring-2 focus:ring-dt-primary/30"
                  >
                </div>
              </div>
            </div>

            <div v-if="pending" class="py-12">
              <AppSkeleton variant="table-row" :count="5" />
            </div>

            <div v-else class="overflow-x-auto">
              <table class="w-full text-left border-collapse">
                <thead>
                  <tr class="text-[10px] font-bold uppercase tracking-widest text-dt-text-soft bg-dt-surface-strong border-b border-dt-border">
                    <th class="px-6 py-3 cursor-pointer hover:text-dt-info transition-colors" @click="sortBy('symbol')">{{ t('stock.symbol') }}</th>
                    <th class="px-6 py-3 text-right">{{ t('stock.dashboard.price') }} / Day %</th>
                    <th class="px-6 py-3 text-right">{{ t('stock.dashboard.marketValue') }}</th>
                    <th class="px-6 py-3 text-right">{{ t('stock.avgPrice') }}</th>
                    <th class="px-6 py-3 text-right">{{ t('stock.dashboard.unrealizedPL') }}</th>
                    <th class="px-6 py-3 text-right">{{ t('stock.dashboard.portfolioPercent') }}</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-dt-border">
                  <tr
                    v-for="holding in sortedHoldings"
                    :key="holding.symbol"
                    v-memo="[
                      holding.symbol,
                      holding.price,
                      holding.dayChangePercent,
                      holding.marketValue,
                      holding.unrealizedAmount,
                      holding.unrealizedPct
                    ]"
                    class="group hover:bg-dt-surface-strong transition-colors"
                  >
                    <td class="px-6 py-4">
                      <div class="flex flex-col">
                        <NuxtLink
                          :to="`/stocks/${encodeURIComponent(holding.symbol)}`"
                          class="text-sm font-bold text-dt-primary hover:underline"
                        >{{ holding.symbol }}</NuxtLink>
                        <span class="text-[10px] text-dt-text-soft">{{ formatQuantity(holding.quantity) }} {{ t('stock.dashboard.shares') }}</span>
                      </div>
                    </td>
                    <td class="px-6 py-4 text-right">
                      <div class="flex flex-col items-end">
                        <span class="text-sm font-semibold tabular-nums text-dt-text">
                          {{ holding.price ? formatCurrency(holding.price) : '—' }}
                        </span>
                        <span v-if="holding.dayChangePercent !== undefined" class="text-[10px] font-bold tabular-nums" :class="holding.dayChangePercent >= 0 ? 'text-dt-success' : 'text-dt-danger'">
                          {{ holding.dayChangePercent >= 0 ? '▲' : '▼' }} {{ Math.abs(holding.dayChangePercent).toFixed(2) }}%
                        </span>
                      </div>
                    </td>
                    <td class="px-6 py-4 text-right">
                      <div class="text-sm font-medium tabular-nums text-dt-text">
                        {{ holding.marketValue !== null ? formatCurrency(holding.marketValue) : '—' }}
                      </div>
                    </td>
                    <td class="px-6 py-4 text-right">
                      <div class="text-xs text-dt-text-muted tabular-nums">
                        {{ formatCurrency(holding.avgCost) }}
                      </div>
                    </td>
                    <td class="px-6 py-4 text-right">
                      <div class="flex flex-col items-end">
                        <span class="text-sm font-bold tabular-nums" :class="(holding.unrealizedAmount ?? 0) >= 0 ? 'text-dt-success' : 'text-dt-danger'">
                          {{ holding.unrealizedAmount === null ? '—' : `${holding.unrealizedAmount >= 0 ? '+' : ''}${formatCurrency(holding.unrealizedAmount)}` }}
                        </span>
                        <span v-if="holding.unrealizedPct !== null" class="text-[10px] font-medium opacity-80" :class="holding.unrealizedPct >= 0 ? 'text-dt-success' : 'text-dt-danger'">
                          {{ holding.unrealizedPct >= 0 ? '+' : '' }}{{ holding.unrealizedPct.toFixed(2) }}%
                        </span>
                      </div>
                    </td>
                    <td class="px-6 py-4 text-right">
                      <div class="flex items-center justify-end gap-3">
                        <span class="text-xs font-semibold text-dt-text-muted">
                          {{ formatPercentage(holding.totalCost) }}
                        </span>
                        <div class="w-12 bg-dt-surface-strong h-1.5 rounded-full overflow-hidden hidden sm:block">
                          <div class="bg-dt-info h-full" :style="{ width: formatPercentage(holding.totalCost) }"></div>
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- Right Side: Analysis & Charts -->
        <div class="lg:col-span-4 space-y-6">
          <!-- Allocation Card -->
          <div class="panel-dashboard p-6">
            <h3 class="font-bold text-dt-text flex items-center gap-2 mb-6 text-base">
              <Icon name="heroicons:chart-pie" class="text-dt-primary" />
              {{ t('stock.dashboard.assetAllocation') }}
            </h3>

            <div class="flex justify-center mb-6">
              <div class="relative w-48 h-48">
                <svg viewBox="0 0 100 100" class="w-full h-full transform -rotate-90">
                  <circle
                    v-for="(slice, index) in donutSlices"
                    :key="index"
                    cx="50"
                    cy="50"
                    :r="slice.radius"
                    fill="transparent"
                    :stroke="slice.color"
                    :stroke-width="slice.strokeWidth"
                    :stroke-dasharray="slice.dashArray"
                    :stroke-dashoffset="slice.dashOffset"
                    class="transition-[stroke-dashoffset] duration-1000 ease-out"
                  />
                </svg>
                <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span class="text-2xl font-black text-dt-text">{{ totalHoldings }}</span>
                  <span class="text-[10px] font-bold text-dt-text-soft uppercase tracking-widest">{{ t('stock.dashboard.assets') }}</span>
                </div>
              </div>
            </div>

            <div class="space-y-3">
              <div v-for="(slice, index) in pieSlices.slice(0, 5)" :key="index" class="flex items-center justify-between group">
                <div class="flex items-center gap-2">
                  <div class="w-2 h-2 rounded-full" :style="{ backgroundColor: slice.color }"></div>
                  <span class="text-xs font-bold text-dt-text group-hover:text-dt-info transition-colors">{{ slice.label }}</span>
                </div>
                <span class="text-xs font-medium text-dt-text-muted">{{ slice.percentage }}</span>
              </div>
              <div v-if="pieSlices.length > 5" class="pt-2 border-t border-dt-border text-center">
                <span class="text-[10px] font-bold text-dt-text-soft uppercase tracking-widest">{{ t('stock.dashboard.moreAssets', { count: pieSlices.length - 5 }) }}</span>
              </div>
            </div>
          </div>

          <!-- Quick Trade Shortcut -->
          <div class="panel-dashboard p-6 bg-dt-info/5 border-dt-info/30">
            <h3 class="font-bold text-dt-text flex items-center gap-2 mb-4 text-base">
              <Icon name="heroicons:plus-circle" class="text-dt-info" />
              {{ t('stock.dashboard.quickTransaction') }}
            </h3>
            <p class="text-xs text-dt-text-muted mb-4">{{ t('stock.dashboard.quickTransactionDesc') }}</p>
            <NuxtLink to="/diaries/new" class="flex items-center justify-center gap-2 w-full py-2.5 px-4 bg-dt-primary-solid hover:bg-dt-primary-solid-active text-white rounded-dt-md font-bold text-sm transition-all shadow-dt-lg active:scale-95">
              <Icon name="heroicons:pencil-square" class="w-4 h-4" />
              {{ t('stock.dashboard.logNewTrade') }}
            </NuxtLink>
          </div>
        </div>
      </div>

      <!-- ── 績效儀表板 ── -->
      <section class="mt-8">
        <div class="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h2 class="text-lg font-bold text-dt-text flex items-center gap-2">
            <Icon name="heroicons:chart-bar-square" class="text-dt-primary" />
            {{ t('stock.performance.title') }}
          </h2>
          <div class="flex max-w-full flex-wrap items-center gap-2">
            <!-- 匯出按鈕 -->
            <button
              v-if="perfData && perfData.summary.totalClosedTrades > 0"
              @click="exportTrades"
              :disabled="isExporting"
              class="action-btn-muted-dashboard text-xs gap-1.5"
            >
              <Icon
                :name="isExporting ? 'heroicons:arrow-path' : 'heroicons:arrow-down-tray'"
                class="w-4 h-4"
                :class="{ 'animate-spin': isExporting }"
              />
              {{ isExporting ? t('stock.performance.exporting') : t('stock.performance.exportCsv') }}
            </button>
            <!-- 時間範圍切換 -->
            <div class="flex items-center gap-1 rounded-dt-sm border border-dt-border bg-dt-surface-strong p-1">
              <button
                v-for="opt in periodOptions"
                :key="opt.value"
                type="button"
                @click="selectedPeriod = opt.value"
                class="min-h-11 min-w-11 rounded-dt-sm px-3 text-xs font-bold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-dt-primary/30"
                :class="selectedPeriod === opt.value
                  ? 'bg-dt-primary-solid text-white shadow-dt-sm'
                  : 'text-dt-text-muted hover:bg-dt-surface hover:text-dt-text'"
              >
                {{ opt.label }}
              </button>
            </div>
          </div>
        </div>

        <!-- 績效統計卡片 -->
        <div v-if="perfPending" class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div v-for="i in 4" :key="i" class="stats-card animate-pulse">
            <div class="h-3 bg-dt-surface-strong rounded w-20 mb-3"></div>
            <div class="h-7 bg-dt-surface-strong rounded w-28"></div>
          </div>
        </div>

        <div v-else-if="perfData" class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <!-- 勝率 -->
          <div class="stats-card">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-dt-text-muted uppercase tracking-wider">{{ t('stock.performance.winRate') }}</span>
              <Icon name="heroicons:trophy" class="w-5 h-5 text-dt-warning opacity-50" />
            </div>
            <div class="text-2xl font-bold tabular-nums"
              :class="perfData.summary.winRate >= 50 ? 'text-dt-success' : 'text-dt-danger'">
              {{ perfData.summary.totalClosedTrades > 0 ? perfData.summary.winRate.toFixed(1) + '%' : 'N/A' }}
            </div>
            <div class="text-[10px] text-dt-text-soft mt-1">
              {{ t('stock.performance.tradeRecord', { wins: perfData.summary.wins, losses: perfData.summary.losses, count: perfData.summary.totalClosedTrades }) }}
            </div>
          </div>

          <!-- 已實現損益 -->
          <div class="stats-card">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-dt-text-muted uppercase tracking-wider">{{ t('stock.performance.realizedPnL') }}</span>
              <Icon name="heroicons:currency-dollar" class="w-5 h-5 text-dt-success opacity-50" />
            </div>
            <div class="text-2xl font-bold tabular-nums"
              :class="perfData.summary.totalRealizedPnL >= 0 ? 'text-dt-success' : 'text-dt-danger'">
              {{ perfData.summary.totalRealizedPnL >= 0 ? '+' : '' }}{{ formatCurrency(perfData.summary.totalRealizedPnL) }}
            </div>
            <div class="text-[10px] text-dt-text-soft mt-1">{{ t('stock.performance.realizedPnLHint') }}</div>
          </div>

          <!-- 最大回撤 -->
          <div class="stats-card">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-dt-text-muted uppercase tracking-wider">{{ t('stock.performance.maxDrawdown') }}</span>
              <Icon name="heroicons:arrow-trending-down" class="w-5 h-5 text-dt-danger opacity-50" />
            </div>
            <div class="text-2xl font-bold tabular-nums"
              :class="perfData.summary.maxDrawdownPct > 20 ? 'text-dt-danger' : 'text-dt-text'">
              {{ perfData.summary.totalClosedTrades > 0 ? '-' + perfData.summary.maxDrawdownPct.toFixed(1) + '%' : 'N/A' }}
            </div>
            <div class="text-[10px] text-dt-text-soft mt-1">{{ t('stock.performance.maxDrawdownHint') }}</div>
          </div>

          <!-- 夏普比率 -->
          <div class="stats-card">
            <div class="flex items-center justify-between mb-2">
              <span class="text-xs font-semibold text-dt-text-muted uppercase tracking-wider">{{ t('stock.performance.sharpe') }}</span>
              <Icon name="heroicons:scale" class="w-5 h-5 text-dt-secondary opacity-50" />
            </div>
            <div class="text-2xl font-bold tabular-nums"
              :class="perfData.summary.sharpe === null ? 'text-dt-text-soft' :
                perfData.summary.sharpe >= 1 ? 'text-dt-success' :
                perfData.summary.sharpe >= 0 ? 'text-dt-warning' : 'text-dt-danger'">
              {{ perfData.summary.sharpe !== null ? perfData.summary.sharpe.toFixed(2) : 'N/A' }}
            </div>
            <div class="text-[10px] text-dt-text-soft mt-1">{{ t('stock.performance.sharpeHint') }}</div>
          </div>
        </div>

        <!-- 損益趨勢圖 -->
        <div v-if="perfData && perfData.periodStats.length > 0" class="panel-dashboard p-6 mb-6">
          <h3 class="font-bold text-dt-text flex items-center gap-2 mb-6 text-sm">
            <Icon name="heroicons:chart-bar" class="text-dt-primary" />
            {{ t('stock.performance.pnlTrend', { period: periodLabel }) }}
          </h3>
          <div class="h-56">
            <Bar :data="barChartData" :options="barChartOptions" />
          </div>
        </div>

        <!-- 空狀態 -->
        <div v-else-if="!perfPending && (!perfData || perfData.summary.totalClosedTrades === 0)"
          class="panel-dashboard p-10 text-center">
          <Icon name="heroicons:chart-bar-square" class="w-12 h-12 text-dt-text-soft mx-auto mb-3" />
          <p class="text-sm font-medium text-dt-text-muted">{{ t('stock.performance.emptyTitle') }}</p>
          <p class="text-xs text-dt-text-soft mt-1">{{ t('stock.performance.emptyDescription') }}</p>
        </div>

        <!-- 資金曲線（折線圖） -->
        <div v-if="perfData && perfData.equityCurve && perfData.equityCurve.length > 1" class="panel-dashboard p-6 mb-6">
          <h3 class="font-bold text-dt-text flex items-center gap-2 mb-6 text-sm">
            <Icon name="heroicons:chart-bar" class="text-dt-primary" />
            {{ t('stock.performance.equityCurve') }}
          </h3>
          <div class="h-48">
            <Line :data="equityCurveData" :options="equityCurveOptions" />
          </div>
        </div>

        <!-- 各股票損益分析（橫條圖） -->
        <div v-if="perfData && perfData.symbolBreakdown && perfData.symbolBreakdown.length > 0" class="panel-dashboard p-6 mb-6">
          <h3 class="font-bold text-dt-text flex items-center gap-2 mb-6 text-sm">
            <Icon name="heroicons:chart-bar" class="text-dt-success" />
            {{ t('stock.performance.bySymbol') }}
          </h3>
          <div :style="{ height: Math.min(perfData.symbolBreakdown.length, 10) * 36 + 24 + 'px' }">
            <Bar :data="symbolBarData" :options="symbolBarOptions" />
          </div>
        </div>

        <!-- 最佳 / 最差交易 -->
        <div v-if="perfData && (perfData.topWins.length > 0 || perfData.topLosses.length > 0)"
          class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Top Wins -->
          <div class="panel-dashboard overflow-hidden">
            <div class="px-5 py-4 border-b border-dt-border bg-dt-success/10">
              <h3 class="text-sm font-bold text-dt-success flex items-center gap-2">
                <Icon name="heroicons:arrow-trending-up" class="w-4 h-4" />
                {{ t('stock.performance.topWins') }}
              </h3>
            </div>
            <div class="divide-y divide-dt-border">
              <div v-for="t in perfData.topWins" :key="t.id" class="px-5 py-3 flex items-center justify-between">
                <div>
                  <span class="text-sm font-bold text-dt-text">{{ t.symbol }}</span>
                  <span class="ml-2 text-xs text-dt-text-soft">{{ formatTradeDate(t.sellDate) }}</span>
                </div>
                <div class="text-right">
                  <div class="text-sm font-bold text-dt-success tabular-nums">
                    +{{ formatCurrency(t.realizedPnL) }}
                  </div>
                  <div class="text-[10px] text-dt-success tabular-nums">+{{ t.realizedPnLPct.toFixed(1) }}%</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Top Losses -->
          <div class="panel-dashboard overflow-hidden">
            <div class="px-5 py-4 border-b border-dt-border bg-dt-danger/10">
              <h3 class="text-sm font-bold text-dt-danger flex items-center gap-2">
                <Icon name="heroicons:arrow-trending-down" class="w-4 h-4" />
                {{ t('stock.performance.topLosses') }}
              </h3>
            </div>
            <div class="divide-y divide-dt-border">
              <div v-for="t in perfData.topLosses" :key="t.id" class="px-5 py-3 flex items-center justify-between">
                <div>
                  <span class="text-sm font-bold text-dt-text">{{ t.symbol }}</span>
                  <span class="ml-2 text-xs text-dt-text-soft">{{ formatTradeDate(t.sellDate) }}</span>
                </div>
                <div class="text-right">
                  <div class="text-sm font-bold text-dt-danger tabular-nums">
                    {{ formatCurrency(t.realizedPnL) }}
                  </div>
                  <div class="text-[10px] text-dt-danger tabular-nums">{{ t.realizedPnLPct.toFixed(1) }}%</div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </section>
    </section>
  </PageContainer>
</template>

<script setup lang="ts">
import { ref, watch, computed } from 'vue'
import { Bar, Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  type ChartData,
  type ChartOptions,
  BarElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
  LineElement,
  PointElement,
  Filler,
} from 'chart.js'
import type { QuoteResponse } from '~/lib/market-data/yahoo'
import { formatCurrency } from '~/lib/format'
import {
  performancePeriodLabel,
  performancePeriodOptions,
  type PerformanceStatsPayload,
  type PerfPeriod,
} from '~/lib/performance-stats'
import { watchDebounced } from '@vueuse/core'
import { usePortfolioExposure } from '~/composables/usePortfolioExposure'

ChartJS.register(BarElement, LinearScale, CategoryScale, Tooltip, Legend, LineElement, PointElement, Filler)

// Track cooldown timer for cleanup
let cooldownTimer: ReturnType<typeof setInterval> | null = null
import {
  buildHoldingChartSegments,
  formatHoldingQuantity,
  formatHoldingShare,
} from '~/lib/stocks-analytics'
import {
  applyStocksView,
  computePortfolioAggregations,
  type ConcentrationFilter,
  type HoldingView,
  type HoldingViewInput,
  type ProfitStatusFilter,
  type SortDirection,
  type StocksSortKey
} from '~/lib/stocks-view'

const { t } = useI18n()
const { formatLocaleDate, formatLocaleDateTime } = useTimezone()

definePageMeta({
  middleware: 'auth'
})

// Fetch holdings from API
const {
  data: holdings,
  pending,
  error: loadError,
  refresh: refreshHoldings,
} = await useLazyFetch<HoldingViewInput[]>(
  '/api/stocks/holdings',
  {
    server: false,
    default: () => []
  }
)

const searchQuery = ref('')
const debouncedSearchQuery = ref('')
const profitStatusFilter = ref<ProfitStatusFilter>('all')
const concentrationFilter = ref<ConcentrationFilter>('all')
const sortColumn = ref<StocksSortKey>('totalCost')
const sortDirection = ref<SortDirection>('desc')
const marketState = ref<string | null>(null)

// Debounce search to avoid excessive re-renders (300ms)
watchDebounced(
  searchQuery,
  (value: string) => {
    debouncedSearchQuery.value = value
  },
  { debounce: 300, maxWait: 1000 }
)

// Sorting logic
const sortBy = (key: StocksSortKey) => {
  if (sortColumn.value === key) {
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortColumn.value = key
    sortDirection.value = 'desc'
  }
}

const baseHoldings = computed(() => holdings.value ?? [])

const sortedHoldings = computed<HoldingView[]>(() => {
  return applyStocksView(baseHoldings.value, {
    search: debouncedSearchQuery.value,
    profitStatus: profitStatusFilter.value,
    concentration: concentrationFilter.value,
    sortKey: sortColumn.value,
    sortDir: sortDirection.value
  })
})

// Stats calculations - use shared aggregation logic (optimized: single computed)
const stats = computed(() => computePortfolioAggregations(baseHoldings.value))
const totalHoldings = computed(() => stats.value.totalHoldings)
const totalCost = computed(() => stats.value.totalCost)
const currentMarketValue = computed(() => stats.value.currentMarketValue)
const unrealizedAmount = computed(() => stats.value.unrealizedAmount)
const totalUnrealizedPct = computed(() => stats.value.unrealizedPct)
const totalDayChange = computed(() => stats.value.totalDayChange)
const totalDayChangePercent = computed(() => stats.value.totalDayChangePercent)
const largestPositionPct = computed(() => stats.value.largestPositionPct)
const top3ConcentrationPct = computed(() => stats.value.top3ConcentrationPct)
const activePositionCount = computed(() => stats.value.activePositionCount)
const concentrationWarning = computed(() => stats.value.concentrationWarning)
const largestPositionSymbol = computed(() => stats.value.largestPositionSymbol)
const pricedPositionCount = computed(() => stats.value.pricedPositionCount)
const unpricedPositionCount = computed(() => stats.value.unpricedPositionCount)
const unpricedCostBasis = computed(() => stats.value.unpricedCostBasis)
const quoteCoveragePct = computed(() => stats.value.quoteCoveragePct)
const valuationAsOf = computed(() => stats.value.valuationAsOf)
const staleQuoteCount = computed(() => stats.value.staleQuoteCount)
const valuationStatus = computed(() => stats.value.valuationStatus)

// Map raw quote marketState (REGULAR/PRE/POST/CLOSED/...) to a localized label
const marketStateLabel = computed(() => {
  const raw = marketState.value
  if (!raw) return ''
  const key = `stock.dashboard.marketStates.${raw}`
  const label = t(key)
  return label === key ? raw : label
})

// ── Portfolio Exposure panel (T7) ──────────────────────────────────
const {
  exposure: portfolioExposure,
  gaps: portfolioExposureGaps,
  betaAllocation: portfolioBetaAllocation,
  marketState: portfolioExposureMarketState,
  lastUpdated: portfolioExposureLastUpdated,
  pending: portfolioExposurePending,
} = usePortfolioExposure()

// Formatting
const formatQuantity = (qty: number) => formatHoldingQuantity(qty)
const formatPercentage = (cost: number) => formatHoldingShare(cost, totalCost.value)
const formatQuoteTime = (value: string) => formatLocaleDateTime(value, {
  dateStyle: 'medium',
  timeStyle: 'short',
})

// Chart data
const donutSlices = computed(() => buildHoldingChartSegments(baseHoldings.value, {
  radius: 38,
  strokeWidth: 12,
}))

const pieSlices = computed(() => donutSlices.value.map(slice => ({
  label: slice.label,
  percentage: slice.percentage,
  color: slice.color,
})))

// Price fetching
const isFetchingPrices = ref(false)
const cooldownRemaining = ref(0)
const COOLDOWN_SECONDS = 30

const fetchStockPrices = async () => {
  if (isFetchingPrices.value || cooldownRemaining.value > 0) return

  const toast = useToast()
  try {
    // Don't show warning if data is still loading or if truly no holdings
    if (!baseHoldings.value.length && !pending.value) {
      toast.warning(t('stock.noHoldingsData'))
      return
    }

    // Wait for initial data to load before fetching prices
    if (pending.value) {
      toast.info(t('stock.dashboard.synchronizing'))
      return
    }

    if (!baseHoldings.value.length) {
      return
    }

    isFetchingPrices.value = true
    const symbols = baseHoldings.value.map(h => h.symbol)

    const pricesData = await $fetch<Record<string, QuoteResponse>>('/api/stocks/prices', {
      method: 'POST',
      body: { symbols }
    })

    // Update holdings with rich data from QuoteResponse
    holdings.value = baseHoldings.value.map(h => {
      const quote = pricesData[h.symbol]
      if (!quote) return h
      
      // Update market state from the first quote
      if (!marketState.value) marketState.value = quote.marketState

      return {
        ...h,
        price: quote.regularMarketPrice,
        dayChange: quote.change,
        dayChangePercent: quote.changePercent,
        quoteAsOf: quote.lastUpdateTime,
      }
    })

    toast.success(t('stock.dashboard.portfolioUpdated'))

    // Cooldown logic with cleanup
    cooldownRemaining.value = COOLDOWN_SECONDS
    cooldownTimer = setInterval(() => {
      cooldownRemaining.value--
      if (cooldownRemaining.value <= 0 && cooldownTimer) {
        clearInterval(cooldownTimer)
        cooldownTimer = null
      }
    }, 1000)
  } catch {
    toast.error(t('stock.dashboard.couldNotRefresh'))
  } finally {
    isFetchingPrices.value = false
  }
}

// Initial fetch - wait for data to load before fetching prices
watch(
  () => [pending.value, baseHoldings.value.length] as const,
  ([isPending, holdingsCount]) => {
    // Only fetch prices when initial data load completes and we have holdings
    if (!isPending && holdingsCount > 0 && !marketState.value) {
      fetchStockPrices()
    }
  },
  { immediate: true }
)

// Cleanup cooldown timer on component unmount
onScopeDispose(() => {
  if (cooldownTimer) {
    clearInterval(cooldownTimer)
    cooldownTimer = null
  }
})

// ─── 績效儀表板 ───────────────────────────────────────────────────────────────

const stockPeriodOptionLabel = (key: string) => {
  const period = key.split('.').at(-1)
  return t(`stock.performance.${period === 'month' ? 'periodMonth' : period === 'quarter' ? 'periodQuarter' : 'periodYear'}`)
}
const stockPeriodLabel = (key: string) => {
  const period = key.split('.').at(-1)
  return t(`stock.performance.${period === 'month' ? 'monthly' : period === 'quarter' ? 'quarterly' : 'yearly'}`)
}
const periodOptions = computed(() => performancePeriodOptions(stockPeriodOptionLabel, 'period'))

const selectedPeriod = ref<PerfPeriod>('month')

const periodLabel = computed(() => {
  return performancePeriodLabel(stockPeriodLabel, 'period', selectedPeriod.value)
})

const { data: perfData, pending: perfPending, refresh: refreshPerf } = await useLazyFetch<PerformanceStatsPayload | null>(
  () => `/api/stats/performance?period=${selectedPeriod.value}`,
  { server: false, default: () => null }
)

// 切換時間段時重新拉資料
watch(selectedPeriod, () => refreshPerf())

function formatTradeDate(date: string | Date): string {
  return formatLocaleDate(date, { month: '2-digit', day: '2-digit' })
}

// Chart.js Bar Chart 資料
const barChartData = computed<ChartData<'bar'>>(() => {
  const stats = perfData.value?.periodStats ?? []
  return {
    labels: stats.map((s: any) => s.period),
    datasets: [
      {
        label: t('stock.performance.realizedPnL'),
        data: stats.map((s: any) => s.realizedPnL),
        backgroundColor: stats.map((s: any) =>
          s.realizedPnL >= 0 ? 'rgba(22, 163, 74, 0.75)' : 'rgba(220, 38, 38, 0.75)'
        ),
        borderColor: stats.map((s: any) =>
          s.realizedPnL >= 0 ? 'rgba(22, 163, 74, 1)' : 'rgba(220, 38, 38, 1)'
        ),
        borderWidth: 1,
        borderRadius: 4,
      },
    ],
  }
})

function formatPnLTooltip(ctx: { raw: unknown }): string {
  const value = Number(ctx.raw)
  return ` ${value >= 0 ? '+' : ''}${value.toFixed(2)}`
}

const barChartOptions: ChartOptions<'bar'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: {
      callbacks: {
        label: formatPnLTooltip,
      },
    },
  },
  scales: {
    x: {
      grid: { display: false },
      ticks: { font: { size: 11 } },
    },
    y: {
      grid: { color: 'rgba(148, 163, 184, 0.1)' },
      ticks: {
        font: { size: 11 },
        callback: (v) => (Number(v) >= 0 ? `+${v}` : String(v)),
      },
    },
  },
}

// ─── 資金曲線（折線圖） ───────────────────────────────────────────────────────

const equityCurveData = computed<ChartData<'line'>>(() => {
  const curve = perfData.value?.equityCurve ?? []
  return {
    labels: curve.map((p) => p.date),
    datasets: [
      {
        label: t('stock.performance.cumulativePnL'),
        data: curve.map((p) => p.cumPnL),
        borderColor: 'rgba(99, 102, 241, 0.9)',
        backgroundColor: 'rgba(99, 102, 241, 0.08)',
        borderWidth: 2,
        pointRadius: curve.length <= 30 ? 3 : 0,
        pointHoverRadius: 5,
        fill: true,
        tension: 0.3,
      },
    ],
  }
})

const equityCurveOptions: ChartOptions<'line'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: {
      callbacks: {
        label: formatPnLTooltip,
      },
    },
  },
  scales: {
    x: {
      grid: { display: false },
      ticks: { font: { size: 10 }, maxTicksLimit: 8 },
    },
    y: {
      grid: { color: 'rgba(148, 163, 184, 0.1)' },
      ticks: {
        font: { size: 11 },
        callback: (v) => (Number(v) >= 0 ? `+${v}` : String(v)),
      },
    },
  },
}

// ─── 各股票損益橫條圖 ─────────────────────────────────────────────────────────

const symbolBarData = computed<ChartData<'bar'>>(() => {
  const breakdown = (perfData.value?.symbolBreakdown ?? []).slice(0, 10)
  return {
    labels: breakdown.map((s) => s.symbol),
    datasets: [
      {
        label: t('stock.performance.realizedPnL'),
        data: breakdown.map((s) => Math.round(s.realizedPnL * 100) / 100),
        backgroundColor: breakdown.map((s) =>
          s.realizedPnL >= 0 ? 'rgba(22, 163, 74, 0.75)' : 'rgba(220, 38, 38, 0.75)'
        ),
        borderColor: breakdown.map((s) =>
          s.realizedPnL >= 0 ? 'rgba(22, 163, 74, 1)' : 'rgba(220, 38, 38, 1)'
        ),
        borderWidth: 1,
        borderRadius: 4,
      },
    ],
  }
})

const symbolBarOptions: ChartOptions<'bar'> = {
  indexAxis: 'y',
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: {
      callbacks: {
        label: formatPnLTooltip,
      },
    },
  },
  scales: {
    x: {
      grid: { color: 'rgba(148, 163, 184, 0.1)' },
      ticks: {
        font: { size: 11 },
        callback: (v) => (Number(v) >= 0 ? `+${v}` : String(v)),
      },
    },
    y: {
      grid: { display: false },
      ticks: { font: { size: 12, weight: 'bold' } },
    },
  },
}

// ─── CSV 匯出 ─────────────────────────────────────────────────────────────────

const isExporting = ref(false)

async function exportTrades() {
  if (isExporting.value) return
  const toast = useToast()
  isExporting.value = true
  try {
    const response = await $fetch<string>('/api/stats/export-trades', {
      responseType: 'text',
    })
    const blob = new Blob([response], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `trades-${new Date().toISOString().slice(0, 10)}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success(t('stock.performance.exportSuccess'))
  } catch {
    toast.error(t('stock.performance.exportFailed'))
  } finally {
    isExporting.value = false
  }
}

useHead({
  title: `${t('stock.dashboard.title')} - Investment Diary`
})
</script>

<style scoped>
.stocks-page {
  background: var(--color-background);
}

.panel-dashboard {
  border: 1px solid var(--color-border);
  border-radius: 1rem;
  background: var(--color-surface);
  box-shadow: var(--shadow-sm);
}

.stats-card {
  border: 1px solid var(--color-border);
  border-radius: 1rem;
  padding: 1.25rem;
  background: var(--color-surface);
  box-shadow: var(--shadow-sm);
  transition: border-color var(--motion-fast) ease, box-shadow var(--motion-fast) ease;
}

.stats-card:hover {
  border-color: var(--color-border-strong);
}

.risk-metric {
  min-width: 0;
  border: 1px solid var(--color-border);
  border-radius: 1rem;
  background: color-mix(in srgb, var(--color-surface-strong) 70%, transparent);
  padding: 1rem;
}

.risk-metric span {
  display: block;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-text-soft);
}

.risk-metric strong {
  display: block;
  margin-top: 0.45rem;
  overflow-wrap: anywhere;
  font-family: var(--font-data);
  font-size: 1.35rem;
  line-height: 1.2;
  color: var(--color-text);
}

.risk-metric small {
  display: block;
  margin-top: 0.35rem;
  color: var(--color-text-muted);
}

.action-btn-dashboard {
  display: inline-flex;
  min-height: 2.75rem;
  align-items: center;
  justify-content: center;
  border-radius: 0.75rem;
  border: 1px solid var(--color-primary);
  background: var(--color-primary);
  padding: 0.5rem 1rem;
  font-size: 0.875rem;
  font-weight: 700;
  color: var(--color-on-ink);
}

.action-btn-dashboard:hover {
  opacity: 0.92;
}

.action-btn-dashboard:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}

.action-btn-muted-dashboard {
  display: inline-flex;
  min-height: 2.75rem;
  align-items: center;
  justify-content: center;
  padding: 0.5rem 1rem;
  border-radius: 0.75rem;
  border: 1px solid var(--color-border);
  background: var(--color-surface-strong);
  color: var(--color-text-muted);
  font-size: 0.875rem;
  font-weight: 700;
  transition: background-color var(--motion-fast) ease, color var(--motion-fast) ease, border-color var(--motion-fast) ease;
}

.action-btn-muted-dashboard:hover {
  background: color-mix(in srgb, var(--color-surface-strong) 92%, transparent);
  color: var(--color-text);
  border-color: var(--color-border-strong);
}

/* Custom scrollbar for table */
.overflow-x-auto::-webkit-scrollbar {
  height: 6px;
}
.overflow-x-auto::-webkit-scrollbar-track {
  background: transparent;
}
.overflow-x-auto::-webkit-scrollbar-thumb {
  background: color-mix(in srgb, var(--color-border) 88%, transparent);
  border-radius: 999px;
}
</style>
